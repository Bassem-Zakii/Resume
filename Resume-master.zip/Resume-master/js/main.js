/*global $*/

$(function () {
    
    'use strict';
    
    $("#myImg").animate({
        opacity: "1"
    }, 1700);
    
});